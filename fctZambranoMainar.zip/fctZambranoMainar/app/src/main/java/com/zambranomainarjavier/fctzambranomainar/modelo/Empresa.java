package com.zambranomainarjavier.fctzambranomainar.modelo;

import java.util.List;

public class Empresa {
    private int id;
    private String nombre;
    private String direccion;
    private String telefono;
    private String email;
    private String linkedIn;
    private List<Tag> listaTags;

    public Empresa(int id, String nombre, String direccion, String telefono, String email, String linkedIn, List<Tag> listaTags) {
        this.id = id;
        this.nombre = nombre;
        this.direccion = direccion;
        this.telefono = telefono;
        this.email = email;
        this.linkedIn = linkedIn;
        this.listaTags = listaTags;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public List<Tag> getListaTags() {
        return listaTags;
    }

    public String toString() {
        return "Id Empresa: " + id +
                "\nNombre: " + nombre +
                "\nDirección: " + direccion +
                "\nTeléfono: " + telefono +
                "\nEmail: " + email +
                "\nLinkedIn: " + linkedIn +
                "\nTags: " + listaTags.toString();
    }
}
