package com.zambranomainarjavier.fctzambranomainar.modelo;

public class Empresa_Tag {
    private int id_empresa;
    private int id_tag;

    public Empresa_Tag(int id_empresa, int id_tag) {
        this.id_empresa = id_empresa;
        this.id_tag = id_tag;
    }

    public int getId_empresa() {
        return id_empresa;
    }

    public int getId_tag() {
        return id_tag;
    }

    public String toString() {
        return "Id Empresa: " + id_empresa +
                "\nId Tag: " + id_tag;
    }
}
