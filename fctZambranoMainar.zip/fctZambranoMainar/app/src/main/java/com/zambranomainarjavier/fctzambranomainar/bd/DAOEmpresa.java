package com.zambranomainarjavier.fctzambranomainar.bd;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.zambranomainarjavier.fctzambranomainar.modelo.Empresa;
import com.zambranomainarjavier.fctzambranomainar.modelo.Tag;

import java.util.ArrayList;
import java.util.List;

public class DAOEmpresa {
    private SQLiteDatabase db;

    public DAOEmpresa(Context context) {
        BBDDSQLite bbdd = new BBDDSQLite(context);
        db = bbdd.getReadableDatabase();
    }

    // Obtener todas las empresas con sus tags asociados
    public List<Empresa> getTodasEmpresasConTags() {
        List<Empresa> lista = new ArrayList<>();
        Cursor cursorEmpresa = db.rawQuery("SELECT * FROM empresa", null);

        if (cursorEmpresa.moveToFirst()) {
            do {
                int id = cursorEmpresa.getInt(0);
                String nombre = cursorEmpresa.getString(1);
                String direccion = cursorEmpresa.getString(2);
                String telefono = cursorEmpresa.getString(3);
                String email = cursorEmpresa.getString(4);
                String linkedIn = cursorEmpresa.getString(5);

                // Obtener los tags asociados a esta empresa
                List<Tag> listaTags = new ArrayList<>();
                Cursor cursorTags = db.rawQuery(
                        "SELECT t.id, t.nombre FROM tag t " +
                                "INNER JOIN empresa_tag et ON t.id = et.tag_id " +
                                "WHERE et.empresa_id = ?",
                        new String[]{ String.valueOf(id) }
                );

                if (cursorTags.moveToFirst()) {
                    do {
                        int tagId = cursorTags.getInt(0);
                        String tagNombre = cursorTags.getString(1);
                        listaTags.add(new Tag(tagId, tagNombre));
                    } while (cursorTags.moveToNext());
                }
                cursorTags.close();

                Empresa e = new Empresa(id, nombre, direccion, telefono, email, linkedIn, listaTags);
                lista.add(e);

            } while (cursorEmpresa.moveToNext());
        }
        cursorEmpresa.close();
        return lista;
    }
}
