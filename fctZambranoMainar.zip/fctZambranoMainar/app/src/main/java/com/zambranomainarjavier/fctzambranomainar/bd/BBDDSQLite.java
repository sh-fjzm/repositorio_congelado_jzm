package com.zambranomainarjavier.fctzambranomainar.bd;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class BBDDSQLite extends SQLiteOpenHelper {

    private static final String NOMBRE_BD = "empresas.db";
    private static final int VERSION_BD = 1;

    public BBDDSQLite(Context context) {
        super(context, NOMBRE_BD, null, VERSION_BD);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Crear tablas
        db.execSQL("CREATE TABLE empresa (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nombre TEXT NOT NULL, " +
                "direccion TEXT, " +
                "telefono TEXT, " +
                "email TEXT, " +
                "linkedIn TEXT)");

        db.execSQL("CREATE TABLE tag (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "nombre TEXT NOT NULL)");

        db.execSQL("CREATE TABLE empresa_tag (" +
                "empresa_id INTEGER NOT NULL, " +
                "tag_id INTEGER NOT NULL, " +
                "PRIMARY KEY (empresa_id, tag_id), " +
                "FOREIGN KEY (empresa_id) REFERENCES empresa(id) ON DELETE CASCADE, " +
                "FOREIGN KEY (tag_id) REFERENCES tag(id) ON DELETE CASCADE)");

        // Insertar empresas
        insertarEmpresa(db, "Integra", "Plaza Roma F1, 1º planta\n50010, Zaragoza", "976 46 78 78",
                "hola@integratecnologia.es", "https://es.linkedin.com/company/integra-estrategia-tecnologia");

        insertarEmpresa(db, "Hiberus", "Paseo de Isabel la Católica, 6\n50009,Zaragoza", null, null,
                "https://www.linkedin.com/company/hiberus");

        // Insertar tags
        String[] tags = {
                ".NET", "Angular", "SAP", "Salesforce", "Magento", "React", "DevOps", "Java", "REST", "C#",
                "Azure", "GIT", "Postman", "SQL", "Spring Boot", "Low Code", "Sharepoint",
                "Power Bi", "Power Apps", "Power Automate", "Power Platform", "XAML"
        };
        for (String tag : tags) {
            insertarTag(db, tag);
        }

        // Insertar relaciones
        int[] integraTags = {8, 1, 16, 17, 18, 19, 20, 21, 10, 23};
        for (int tagId : integraTags) {
            insertarRelacionEmpresaTag(db, 1, tagId);
        }

        int[] hiberusTags = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
        for (int tagId : hiberusTags) {
            insertarRelacionEmpresaTag(db, 2, tagId);
        }
    }

    private void insertarEmpresa(SQLiteDatabase db, String nombre, String direccion, String telefono, String email, String linkedIn) {
        db.execSQL("INSERT INTO empresa (nombre, direccion, telefono, email, linkedIn) " +
                        "VALUES (?, ?, ?, ?, ?)",
                        new Object[]{nombre, direccion, telefono, email, linkedIn});
    }

    private void insertarTag(SQLiteDatabase db, String nombre) {
        db.execSQL("INSERT INTO tag (nombre) VALUES (?)",
                        new Object[]{nombre});
    }

    private void insertarRelacionEmpresaTag(SQLiteDatabase db, int empresaId, int tagId) {
        db.execSQL("INSERT INTO empresa_tag (empresa_id, tag_id) VALUES (?, ?)",
                        new Object[]{empresaId, tagId});
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS empresa_tag");
        db.execSQL("DROP TABLE IF EXISTS empresa");
        db.execSQL("DROP TABLE IF EXISTS tag");
        onCreate(db);
    }
}
